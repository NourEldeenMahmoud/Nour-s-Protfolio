---
title: Obsidian Flavored Markdown Reference
date: 2026-05-25
tags:
  - reference
  - obsidian
  - markup
aliases:
  - OFM Reference
  - Markdown Cheat Sheet
cssclasses:
  - reference-note
status: complete
version: 1.0
---
# Obsidian Flavored Markdown Reference

A complete cheat sheet covering every feature in the Obsidian Flavored Markdown skill. Use this note as a quick lookup for syntax.

---

## Headings

# H1
## H2
### H3
#### H4
##### H5
###### H6

---

## Text Formatting

**Bold text**, *Italic text*, ~~Strikethrough text~~, ==Highlighted text==, `Inline code`.

---

## Lists

### Bullet List

- Item one
- Item two
  - Nested item A
  - Nested item B

### Numbered List

1. First step
2. Second step
   1. Sub-step A
   2. Sub-step B

### Task List

- [x] Completed task
- [ ] Pending task
- [ ] Another pending task

---

## Blockquotes

> Single line blockquote.

> Multi-line
> blockquote
> spanning several lines.

---

## Thematic Break

---

## Code Blocks

```javascript
function greet(name) {
  return `Hello, ${name}!`;
}
```

```html
<button class="primary">Click me</button>
```

```css
.container {
  display: flex;
  gap: 1rem;
}
```

```json
{
  "name": "Example",
  "version": "1.0"
}
```

```http
GET /api/notes HTTP/1.1
Host: localhost
Accept: application/json
```

```bash
npm install obsidian --save
```

```csharp
public class Note
{
    public string Title { get; set; }
}
```

```text
Plain text block with no syntax highlighting.
```

Inline references: use the `fetch()` API with an `async` function and `await` the response.

---

## Tables

| Feature   | Syntax       | Example       |
| --------- | ------------ | ------------- |
| Bold      | `**text**`   | **Bold**      |
| Italic    | `*text*`     | *Italic*      |
| Code      | `` `code` `` | `code`        |
| Highlight | `==text==`   | ==Highlight== |

---

## Links

### Wikilinks (Internal)

[[Note Name]]
[[Note Name|Custom Display Text]]
[[Note Name#Heading]]
[[Note Name#^block-id]]
[[#Heading in same note]]

### Markdown Links (External)

[Obsidian Help](https://help.obsidian.md)

---

## Block IDs

Attach `^block-id` to any paragraph for block-level linking.

This paragraph has a block ID. ^my-block-id

For lists:

- List item one
- List item two

^list-id

For quotes:

> This is a blockquote with a block ID.

^quote-id

Referenced via [[#^my-block-id]] or [[Other Note#^list-id]].

---

## Embeds

### Notes

```markdown
![[Obsidian Flavored Markdown Reference#Block IDs]]
![[Obsidian Flavored Markdown Reference#^my-block-id]]
```

### Images

```markdown
![[example-image.png]]
![[example-image.png|300]]
![[example-image.png|640x480]]
![Alt text](https://example.com/image.png)
![Alt text|300](https://example.com/image.png)
```

### HTML Images (Centered)

```html
<p align="center">
  <img src="https://example.com/image.png" width="300">
</p>
```

### PDF

```markdown
![[document.pdf]]
![[document.pdf#page=3]]
![[document.pdf#height=400]]
```

### Audio

```markdown
![[audio.mp3]]
![[audio.ogg]]
```

### Search Results

```query
tag:#reference
```

---

## Callouts

### Basic Callouts

> [!note]
> Basic note callout.

> [!info] Custom Title
> Callout with a custom title.

> [!tip] Title Only

### Custom Titles (Any Language)

Callout titles can be in Arabic or any language:

> [!Abstract] مقدمة
> Callout with an Arabic title.

> [!tip] بصمجيات
> Quick summary callout.

> [!summary] كده خلصنا
> Recap callout.

### All Callout Types

| Type        | Aliases                    |
|-------------|----------------------------|
| `note`      |                            |
| `abstract`  | `summary`, `tldr`          |
| `info`      |                            |
| `todo`      |                            |
| `tip`       | `hint`, `important`        |
| `success`   | `check`, `done`            |
| `question`  | `help`, `faq`              |
| `warning`   | `caution`, `attention`     |
| `failure`   | `fail`, `missing`          |
| `danger`    | `error`                    |
| `bug`       |                            |
| `example`   |                            |
| `quote`     | `cite`                     |

> [!abstract]
> Abstract / summary / tldr callout.

> [!todo]
> Todo callout content.

> [!success] Done
> Success / check / done callout.

> [!question] FAQ
> Question / help / faq callout.

> [!warning] Caution
> Warning / caution / attention callout.

> [!failure]
> Failure / fail / missing callout.

> [!danger] Error
> Danger / error callout.

> [!bug]
> Bug callout content.

> [!example]
> Example callout content.

> [!quote] Cite
> Quote / cite callout content.

### Foldable Callouts

> [!faq]- Collapsed by default
> This content is hidden until expanded.

> [!faq]+ Expanded by default
> This content is visible but can be collapsed.

### Nested Callouts

> [!question] Outer
> > [!note] Inner
> > Nested content inside the outer callout.

---

## Tags

### Inline Tags

#reference #obsidian/markdown #obsidian/callouts
#nested/tag #tag-with-dashes #tag_with_underscores

### Frontmatter Tags

```yaml
---
tags:
  - reference
  - obsidian
  - nested/tag
---
```

---

## Comments

```markdown
This is visible %%but this is hidden%% text.

%%
This entire block is hidden in reading view.
%%
```

---

## Math (LaTeX)

Inline: $e^{i\pi} + 1 = 0$

Block:
$$
\frac{a}{b} = c
$$

---

## Diagrams (Mermaid)

```mermaid
graph TD
    A[Start] --> B{Is it valid?}
    B -->|Yes| C[Continue]
    B -->|No| D[Fix it]
    C --> E[Finish]
    D --> E

    class C internal-link;
    class D internal-link;
```

Additional Mermaid diagram types:

```mermaid
sequenceDiagram
    participant User
    participant App
    User->>App: Save note
    App->>App: Validate syntax
    App-->>User: Confirmation
```

```mermaid
classDiagram
    class Note {
        +String title
        +String content
        +render()
    }
    class ImageNote {
        +String path
        +render()
    }
    Note <|-- ImageNote
```

---

## Footnotes

This sentence has a footnote[^1].

[^1]: The footnote content appears at the bottom.

This sentence has an inline footnote.^[The inline footnote text.]

---

## Dataview

### TABLE

```dataview
TABLE title, status, date
FROM "Example"
WHERE status = "complete"
SORT date DESC
```

### LIST

```dataview
LIST FROM #reference
```

### TASK

```dataview
TASK FROM "Example"
WHERE !completed
```

### CALENDAR

```dataview
CALENDAR date
FROM #reference
```

### DataviewJS

```dataviewjs
dv.list(dv.pages("#reference").map(page => page.file.link))
```

---

## Mixed Arabic-English Direction

When a line starts with an English term and contains Arabic after it, prefix with `ا` for direction control.

اJavaScript هي لغة برمجة.
اVS Code محرر أكواد مجاني.
HTML و CSS و JavaScript — التقنيات الأساسية.

Do not apply the `ا` prefix to headings, code blocks, URLs, API paths, JSON keys, commands, or pure English lines.

---

## Properties (Frontmatter) Reference

| Type          | Example                                      |
|---------------|----------------------------------------------|
| Text          | `title: My Note`                             |
| Number        | `rating: 4.5`                              |
| Checkbox      | `completed: true`                            |
| Date          | `date: 2026-05-25`                           |
| Date & Time   | `due: 2026-05-25T14:30:00`                   |
| List          | `tags: [one, two]` or YAML list              |
| Link          | `related: "[[Other Note]]"`                  |

---

## Custom Callouts (CSS)

```css
.callout[data-callout="custom-type"] {
  --callout-color: 255, 0, 0;
  --callout-icon: lucide-alert-circle;
}
```
