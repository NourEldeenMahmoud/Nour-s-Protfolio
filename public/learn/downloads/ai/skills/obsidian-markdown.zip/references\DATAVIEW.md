# Dataview Reference

Use Dataview when an Obsidian note needs generated views from note properties, tags, folders, or tasks.

Do not use Dataview just to make a note look advanced. Use it only when the generated view helps the reader.

## Query Types

### Table

```dataview
TABLE title, status, date
FROM "Courses"
WHERE status = "in-progress"
SORT date DESC
```

### List

```dataview
LIST FROM #course-note
```

### Task

```dataview
TASK FROM "Courses"
WHERE !completed
```

### Calendar

```dataview
CALENDAR date
FROM #course-note
```

## Common Sources

```dataview
FROM "Folder Name"
FROM #tag
FROM [[Linked Note]]
```

## Common Filters

```dataview
WHERE status = "done"
WHERE contains(tags, "course-note")
WHERE date >= date(today) - dur(7 days)
```

## DataviewJS

Use DataviewJS only when normal Dataview Query Language cannot express the needed result.

````markdown
```dataviewjs
dv.list(dv.pages("#course-note").map(page => page.file.link))
```
````

Prefer normal Dataview queries for readable notes.
