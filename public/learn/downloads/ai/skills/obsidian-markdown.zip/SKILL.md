﻿---
name: obsidian-markdown
description: Create and edit Obsidian Flavored Markdown with wikilinks, embeds, callouts, properties, Dataview, tables, and Obsidian-specific syntax. Supports two writing modes for note content: native Egyptian Arabic mode and English mode. Use when working with .md files in Obsidian, or when the user mentions wikilinks, callouts, frontmatter, tags, embeds, Dataview, Obsidian notes, course notes, study notes, or Egyptian Arabic lesson notes.
---

# Obsidian Flavored Markdown Skill

Create and edit valid Obsidian Flavored Markdown. Obsidian extends CommonMark and GFM with wikilinks, embeds, callouts, properties, comments, and other syntax. This skill covers only Obsidian-specific extensions -- standard Markdown (headings, bold, italic, lists, quotes, code blocks, tables) is assumed knowledge.

When the user is creating study notes, course notes, summaries, or lesson notes, also apply the note-writing rules in this skill: preserve full source coverage, keep the note simple and scannable, avoid filler/jokes/emojis/unsupported additions, and choose one of two writing modes.

## Writing Modes

Choose exactly one mode for prose content in the note:

1. **Native Egyptian Arabic Mode** (default for study notes and summaries unless user asks otherwise)
2. **English Mode** (use when user explicitly asks for English)

Mode rules:

- Keep technical terms, commands, identifiers, URLs, and code in their original form in both modes.
- Do not mix modes in the same note unless the user explicitly requests bilingual output.
- If the user does not specify language and the task is educational notes/summaries, use Native Egyptian Arabic Mode.

## Workflow: Creating an Obsidian Note

1. **Add frontmatter** with properties (title, tags, aliases) at the top of the file. See [PROPERTIES.md](references/PROPERTIES.md) for all property types.
2. **Write content** using standard Markdown for structure, plus Obsidian-specific syntax below.
3. **Link related notes** using wikilinks (`[[Note]]`) for internal vault connections, or standard Markdown links for external URLs.
4. **Embed content** from other notes, images, or PDFs using the `![[embed]]` syntax. See [EMBEDS.md](references/EMBEDS.md) for all embed types.
5. **Add callouts** for highlighted information using `> [!type]` syntax. See [CALLOUTS.md](references/CALLOUTS.md) for all callout types.
6. **Verify** the note renders correctly in Obsidian's reading view.

## Workflow: Writing Study Notes

1. Preserve all meaningful teaching content from the source.
2. Remove export metadata, download-only sections, and activity/homework/solution-only material when the source is a course export.
3. Select the writing mode:
   - Native Egyptian Arabic Mode by default for study notes/summaries.
   - English Mode if the user explicitly requests English.
4. Write all prose using the selected mode.
5. Keep technical terms, commands, identifiers, URLs, and code in their original form.
6. Use Obsidian syntax intentionally: callouts, tables, embeds, dataview, wikilinks, frontmatter, comments, and media embeds when they improve the note.
7. Keep the final note simple, clean, and not crowded.
8. Verify the rendered note before finishing.

> When choosing between wikilinks and Markdown links: use `[[wikilinks]]` for notes within the vault (Obsidian tracks renames automatically) and `[text](url)` for external URLs only.

## Internal Links (Wikilinks)

```markdown
[[Note Name]]                          Link to note
[[Note Name|Display Text]]             Custom display text
[[Note Name#Heading]]                  Link to heading
[[Note Name#^block-id]]                Link to block
[[#Heading in same note]]              Same-note heading link
```

Define a block ID by appending `^block-id` to any paragraph:

```markdown
This paragraph can be linked to. ^my-block-id
```

For lists and quotes, place the block ID on a separate line after the block:

```markdown
> A quote block

^quote-id
```

## Embeds

Prefix any wikilink with `!` to embed its content inline:

```markdown
![[Note Name]]                         Embed full note
![[Note Name#Heading]]                 Embed section
![[image.png]]                         Embed image
![[image.png|300]]                     Embed image with width
![[document.pdf#page=3]]               Embed PDF page
```

### Attachments and resizing

```markdown
![[file.png|300]]                      Embed image with width (px)
![[file.jpg|640]]                      Embed image with width (px)
![[file.pdf]]                          Embed full PDF
![[file.pdf#page=2]]                   Embed specific PDF page
```

See [EMBEDS.md](references/EMBEDS.md) for audio, video, search embeds, and external images.

### HTML Images (Centered)

Use raw HTML to center images or control sizing. Obsidian renders HTML in markdown files:

```html
<p align="center">
  <img src="https://example.com/image.png" width="300">
</p>

<p align="center">
  <img src="https://example.com/image.png" width="400">
</p>
```

This is preferred over `![[embed]]` when you need center alignment or explicit width control on external URLs. For local images, `![[image.png|300]]` is simpler.

## Callouts

```markdown
> [!note]
> Basic callout.

> [!warning] Custom Title
> Callout with a custom title.

> [!Abstract] Arabic Title
> Callout with an Arabic custom title.

> [!faq]- Collapsed by default
> Foldable callout (- collapsed, + expanded).

> [!tip]+ Expanded by default
> Foldable callout that starts expanded.
```

Common types: `note`, `tip`, `warning`, `info`, `example`, `quote`, `bug`, `danger`, `success`, `failure`, `question`, `abstract`, `todo`.

Callout titles can be in any language. Use custom titles to label callouts with context:

```markdown
> [!Abstract] Ù…Ù‚Ø¯Ù…Ø©
> Content here.

> [!tip] Ø¨ØµÙ…Ø¬ÙŠØ§Øª
> Quick summary here.

> [!summary] ÙƒØ¯Ù‡ Ø®Ù„ØµÙ†Ø§
> Recap content here.
```

See [CALLOUTS.md](references/CALLOUTS.md) for the full list with aliases, nesting, and custom CSS callouts.

## Properties (Frontmatter)

```yaml
---
title: My Note
date: 2024-01-15
tags:
  - project
  - active
aliases:
  - Alternative Name
cssclasses:
  - custom-class
---
```

Default properties: `tags` (searchable labels), `aliases` (alternative note names for link suggestions), `cssclasses` (CSS classes for styling).

See [PROPERTIES.md](references/PROPERTIES.md) for all property types, tag syntax rules, and advanced usage.

## Tags

```markdown
#tag                    Inline tag
#nested/tag             Nested tag with hierarchy
```

Tags can contain letters, numbers (not first character), underscores, hyphens, and forward slashes. Tags can also be defined in frontmatter under the `tags` property.

## Comments

```markdown
This is visible %%but this is hidden%% text.

%%
This entire block is hidden in reading view.
%%
```

## Obsidian-Specific Formatting

```markdown
==Highlighted text==                   Highlight syntax
```

## Math (LaTeX)

```markdown
Inline: $e^{i\pi} + 1 = 0$

Block:
$$
\frac{a}{b} = c
$$
```

## Diagrams (Mermaid)

````markdown
```mermaid
graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Do this]
    B -->|No| D[Do that]
```
````

To link Mermaid nodes to Obsidian notes, add `class NodeName internal-link;`.

## Footnotes

```markdown
Text with a footnote[^1].

[^1]: Footnote content.

Inline footnote.^[This is inline.]
```

## Complete Example

````markdown
---
title: Project Alpha
date: 2024-01-15
tags:
  - project
  - active
status: in-progress
---

# Project Alpha

This project aims to [[improve workflow]] using modern techniques.

> [!important] Key Deadline
> The first milestone is due on ==January 30th==.

## Tasks

- [x] Initial planning
- [ ] Development phase
  - [ ] Backend implementation
  - [ ] Frontend design

## Notes

The algorithm uses $O(n \log n)$ sorting. See [[Algorithm Notes#Sorting]] for details.

![[Architecture Diagram.png|600]]

Reviewed in [[Meeting Notes 2024-01-10#Decisions]].
````

## References

- [Obsidian Flavored Markdown](https://help.obsidian.md/obsidian-flavored-markdown)
- [Internal links](https://help.obsidian.md/links)
- [Embed files](https://help.obsidian.md/embeds)
- [Callouts](https://help.obsidian.md/callouts)
- [Properties](https://help.obsidian.md/properties)
- [Dataview local reference](references/DATAVIEW.md)
- [Local OBFM reference note](references/Obsidian%20Flavored%20Markdown%20Reference.md)
- [Egyptian Arabic Humanizer](<SKILLS_ROOT>/humanizer-ar-egt/SKILL.md) â€” load via `skill` tool to humanize Egyptian Arabic text

## Egyptian Arabic Note Rules

Use these rules when the selected writing mode is Native Egyptian Arabic Mode.

> When writing Egyptian Arabic content, also load the `humanizer-ar-egt` skill to remove AI-generated writing patterns and make the text sound authentically human-written.

### Language and Tone

- Write in native Egyptian Arabic.
- Keep technical terms in English when they already appear in the source.
- Do not add jokes, filler, motivational lines, or extra commentary.
- Do not add unsupported explanations or external details.
- Keep the tone direct, educational, and practical.

## English Note Rules

Use these rules when the selected writing mode is English Mode.

### Language and Tone

- Write in clear, natural English.
- Keep technical terms in the same form used by the source when applicable.
- Do not add jokes, filler, motivational lines, or extra commentary.
- Do not add unsupported explanations or external details.
- Keep the tone direct, educational, and practical.

### Completeness

- Cover 100% of the meaningful content in the source.
- Keep definitions, examples, code blocks, comparisons, warnings, and practical flows when they exist in the source.
- Do not skip a section just because it feels basic.
- Do not duplicate the same point if the source repeats it.
- If something is unclear in the source, keep it marked as unclear instead of guessing.

### Formatting Rules

- Use Markdown.
- Use `---` between major sections.
- Leave one blank line after every heading.
- Prefer bullets over dense paragraphs.
- Split long or crowded paragraphs into short bullets.
- Keep sections visually clear and easy to scan.
- Do not use emojis.
- Do not let the note feel filled with padding or filler text.

### Code and Inline Syntax

- Preserve code blocks when the source includes code, API calls, JSON, commands, or headers.
- Add the correct language label when clear, such as `javascript`, `html`, `css`, `json`, `http`, `bash`, `csharp`, or `text`.
- Format and indent code cleanly for readability without changing behavior.
- If source code is minified or written on one line, pretty-print it while preserving the exact logic.
- Wrap programming operators, keywords, inline expressions, and variable-like terms in backticks inside normal text.

### Completeness

- Cover 100% of the meaningful content in the source.
- Keep definitions, examples, code blocks, comparisons, warnings, and practical flows when they exist in the source.
- Do not skip a section just because it feels basic.
- Do not duplicate the same point if the source repeats it.
- If something is unclear in the source, keep it marked as unclear instead of guessing.

### Formatting Rules

- Use Markdown.
- Use `---` between major sections.
- Leave one blank line after every heading.
- Prefer bullets over dense paragraphs.
- Split long or crowded paragraphs into short bullets.
- Keep sections visually clear and easy to scan.
- Do not use emojis.
- Do not let the note feel filled with padding or filler text.

### Code and Inline Syntax

- Preserve code blocks when the source includes code, API calls, JSON, commands, or headers.
- Add the correct language label when clear, such as `javascript`, `html`, `css`, `json`, `http`, `bash`, `csharp`, or `text`.
- Format and indent code cleanly for readability without changing behavior.
- If source code is minified or written on one line, pretty-print it while preserving the exact logic.
- Wrap programming operators, keywords, inline expressions, and variable-like terms in backticks inside normal text.

### Mixed Arabic-English Direction

- Use `Ø§` only for line-start direction control.
- If a prose line or list item starts with an English term and the same line contains Arabic text after it, add `Ø§` immediately before the English term.
- Do not add `Ø§` before English terms in the middle of Arabic text.
- Do not apply this rule to headings, code blocks, URLs, API paths, JSON keys, commands, or pure English-only lines.

### Obsidian Syntax Usage

- Use callouts when they genuinely help structure the note.
- Use tables only when they improve readability, especially for comparisons.
- Use embeds when an existing note, image, audio, or PDF should be shown inline.
- Use Dataview when the note benefits from querying properties or building lightweight indexes.
- Use wikilinks for internal vault notes and standard links for external URLs.
- Use frontmatter properties when metadata should be machine-readable.

## Dataview Reference

Dataview is useful when a note needs to query other notes, filter by properties, or show a generated list.

### Query Example

```dataview
TABLE title, status, date
FROM "Courses"
WHERE status = "in-progress"
SORT date DESC
```

### List Example

```dataview
LIST FROM #course-note
```

### Task Example

```dataview
TASK FROM "Courses"
WHERE !completed
```

Use Dataview only when it adds real value. Do not add a query just to make the note look advanced.

