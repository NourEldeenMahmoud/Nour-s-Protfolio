---
name: image-content-extraction-rules
description: rules for extracting text and figure content from images (book pages, screenshots, diagrams) into structured markdown. Use for image-content-extractor-worker outputs. Covers verbatim text extraction, figure description, image embed handling, and partial file output. Does not summarize — only extracts.
compatibility: opencode
---

# Image Content Extraction Rules

Use this skill whenever you extract content from images into structured markdown.

## Scope: Image-Based Content Only

This skill is designed for **image-based course content** — book page screenshots, lecture slides, diagram screenshots, and similar visual content that needs text and figure extraction.

**Do NOT use this skill for:**
- Markdown-based course content (use `course-summary-rules` instead)
- Mixed content with both markdown and images (use `course-summary-rules` instead)

---

## Core Principle

Extract ALL visible content from each image — text and figures.

Do not summarize.

Do not paraphrase.

Do not skip content.

The output is raw extracted content, not a summary.

---

## Hard Rules

- Never add information that is not visible in the image.
- Never skip visible text content.
- Never skip visible figures or diagrams.
- Never invent text that is unclear or illegible.
- Never paraphrase or rewrite extracted text.
- Never translate content to another language.
- Never summarize extracted content.
- Never add explanations or interpretations.
- Never add external information or context.

---

## Text Extraction Rules

Extract ALL visible text content from each image, including:

- Headings and titles
- Paragraphs and body text
- Bullet points and lists
- Numbered lists
- Code snippets and commands
- API examples
- Labels and captions
- Table headers and cells
- Footnotes and annotations
- Any other visible text

### Text Extraction Guidelines

- Extract text exactly as it appears in the image.
- Preserve the original language of the content.
- Preserve code blocks exactly as shown — do not reformat.
- Preserve table structure when visible.
- Preserve line breaks between paragraphs.
- If text is partially visible or cut off, extract what is visible.
- If text is blurry or unclear, mark it as `[unclear]` instead of guessing.
- Do not attempt to reconstruct text that is not visible.

---

## Figure and Diagram Rules

For each figure or diagram visible in the image, describe:

- What the figure shows (type: diagram, chart, screenshot, illustration, etc.)
- All labels and annotations
- Arrows and their direction/meaning
- Components and their arrangement
- Relationships between components
- Visual structure and layout
- Any text within the figure (labels, captions, annotations)

### Figure Description Guidelines

- Describe figures with full pedagogical detail.
- Include every visible label and annotation.
- Describe the spatial arrangement of components.
- Describe arrows and their meaning.
- Describe colors if they convey meaning.
- Do not interpret the figure — describe what is visible.
- Do not add external context about the figure.

---

## Image Embed Rules

Include an image embed before each image's extracted content:

- Use Obsidian embed syntax: `![[filename.png|640x480]]`
- Place the embed immediately before the extracted content for that image.
- Use the original filename of the image.
- Preserve the filename exactly as provided in the batch.

---

## Coverage Rules

Extract 100% of the visible content from each image:

- All text content — every word visible in the image.
- All figures — every diagram, chart, screenshot, illustration.
- All labels and annotations within figures.
- All code snippets and commands.
- All table content.

If the source has multiple related points, extract them all without merging or deduplication.

If a detail seems small but is visible, extract it.

---

## No Extra Details

Do not add:

- external explanations
- new examples
- new best practices
- new warnings
- new comparisons
- new terminology
- new sections that are not visible in the image
- assumptions about content
- interpretations of figures

The output must be grounded only in what is visible in each image.

---

## Partial File Output

When writing a batch output (partial file):

- Include a heading with the subfolder name and part number.
- Include all extracted content from the batch.
- Include image embeds for each processed image.
- Do not include the final frontmatter — the assembler adds that.
- Do not include content from other batches.

---

## Language Rules

- Extract content in the original language of the image.
- Do not translate content.
- Do not paraphrase content.
- Preserve technical terms exactly as shown.
- Preserve code and API names exactly as shown.
- Preserve file names and paths exactly as shown.

---

## Final Quality Checklist

Before writing the output, verify:

- All visible text from each image was extracted.
- All figures and diagrams from each image were described.
- Text was extracted verbatim — no paraphrasing.
- Figures were described with full detail.
- Image embeds are included for each processed image.
- No external information was added.
- No content was skipped.
- No content was summarized.
- The original language was preserved.
- Unclear text was marked as `[unclear]`.
- The output follows `obsidian-markdown` formatting.
