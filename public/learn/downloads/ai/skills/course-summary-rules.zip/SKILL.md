---
name: course-summary-rules
description: rules for creating complete Egyptian Arabic course summaries from written Teachable course content (e.g. programming tutorials, technical training, hobby courses exported from Teachable). use for course-summary-worker outputs, subfolder summaries, lesson summaries, anti-hallucination, metadata/download cleanup, activity/homework skipping, source coverage, and no-extra-detail policy. ONLY for courses exported from Teachable. Does not define formatting or syntax; use obsidian-markdown for Markdown, code blocks, callouts, embeds, Dataview, tables, wikilinks, frontmatter, and other note presentation rules.
compatibility: opencode
---

# Course Summary Rules

Use this skill whenever you summarize raw written course content into complete course summaries.

## Scope: Teachable Courses Only

This skill is designed exclusively for **courses exported from Teachable** — e.g., programming tutorials, software engineering bootcamps, technical training, design workshops, hobby/DIY courses, language-learning courses, and similar informal or vocational content hosted on Teachable.

**Do NOT use this skill for:**
- Courses from other platforms (e.g., Udemy, Coursera, Skillshare, Moodle, Educo, ProgrammingAdvices, or custom websites).
- Academic/university courses (e.g., computer science theory, mathematics, physics, history, literature, formal sciences).
- Courses that follow a formal academic syllabus, require citations, or involve scholarly/theoretical content.
- Any content where Egyptian Arabic summarization would be inappropriate or where formal Arabic is expected.

If the course is not from Teachable, do not apply this skill. Use a different approach suitable for the source platform instead.

This skill owns source coverage, cleanup, language, anti-hallucination, and course-summary content policy. It does not own formatting or syntax; use `obsidian-markdown` for Markdown, code blocks, callouts, embeds, Dataview, tables, wikilinks, frontmatter, and other note presentation rules.

---

## Core Principle

The goal is complete coverage, not short summarization.

Cover 100% of the meaningful teaching information in the source lesson.

Do not copy the lesson word-for-word unless needed for code, commands, API examples, exact definitions, or important phrasing.

Do not add any external information.

Do not repeat the same information multiple times if the source repeats it. Keep the meaning once, clearly.

---

## Hard Rules

- Never add information that is not in the source.
- Never include Teachable export metadata such as `Course:`, `Section:`, `Lecture:`, `URL:`, or `Export Date:`.
- Never include download-only sections, source archive links, PDFs, ZIP files, RAR files, or `Complete and Continue`.
- Never include activity/homework/solution lessons.
- Never remove examples, code, demos, or practical flows from normal teaching lessons.
- Never add jokes, motivational lines, personal opinions, or filler.

---

## Language Rules

- Write the summary in Egyptian Arabic.
- Prefer simple Egyptian Arabic when the source is Arabic or mixed Arabic/English.
- Keep technical terms in English when they are used in the source.
- Do not translate technical identifiers, code, API names, headers, commands, file names, URLs, tokens, or operators.
- Use clean Arabic spelling where practical, such as `أفضل`, `إلغاء`, `إيقاف`, `أو`, `الأخطاء`, and `الأنيميشن`.
- Preserve correct English technical spelling, such as `milliseconds`, not `millseconds`.
- Do not add jokes, motivational lines, or personal opinions.
- Keep the tone educational, direct, and practical.

---

## Coverage Rules

Preserve all meaningful teaching information from the source, including:

- definitions
- goals
- motivations
- problems
- solutions
- tradeoffs
- warnings
- misconceptions
- examples
- code blocks
- API examples
- practical flows
- comparisons
- images
- conclusions
- important notes
- edge cases mentioned in the source

If the source repeats the same idea multiple times, summarize it once.

If the source has multiple related points, merge them only if no meaning is lost.

If a detail seems small but changes understanding, include it.

If the source is unclear, mark it as unclear instead of guessing.

---

## No Extra Details

Do not add:

- external explanations
- new examples
- new best practices
- new warnings
- new comparisons
- new terminology
- new sections that are not supported by the lesson
- assumptions about production usage unless the source says them
- exercises or practice ideas unless the source includes them

When mentioning inconsistencies or mismatches in the source, state them neutrally without interpretation or judgment.

The summary must be grounded only in the raw lesson content.

---

## Source Metadata Cleanup

Remove Teachable export metadata from the final summary.

Teachable lesson exports typically begin with metadata, for example:

```text
Course: Web Development Bootcamp
Section: 1 - HTML Basics
Lecture: 2 - What is HTML?
URL: https://programmingadvices.teachable.com/courses/web-dev-bootcamp/lectures/12345678
Export Date: 2026-05-25T10:00:00.000Z
```

Do not include this metadata block in the final summary.

Treat these fields as Teachable export metadata, not lesson content:

- `Course:`
- `Section:`
- `Lecture:`
- `URL:`
- `Export Date:`

If a `---` separator appears immediately after this metadata block, remove it too unless it separates real lesson content.

Do not remove lesson titles, real course headings, examples, code blocks, image links, or meaningful lesson content.

---

## Materials and Downloads Cleanup

Do not include course export/download sections in the final summary.

Remove sections like this:

```text
## Materials / Downloads

- ملف: `Preformatted Text pre.pdf`
- Source Code: `PreformattedTextExample.rar`

---
```

Treat these sections as course assets metadata, not lesson content.

Remove sections with headings like:

- `## Materials / Downloads`
- `## Materials`
- `## Downloads`
- `## Resources`
- `## Attachments`
- `## Source Code`
- `## Use these images`

Remove lines that only list downloadable files, source-code archives, PDFs, ZIP files, RAR files, exported assets, or `Complete and Continue`.

If a lesson file contains only download links, source-code archive links, PDFs, RAR/ZIP files, or `Complete and Continue`, do not create a separate summary section for it.

Do not remove meaningful lesson content that explains the material.

Do not remove code examples, commands, screenshots, diagrams, image links, or files that are part of the lesson explanation.

---

## Activity and Homework Lesson Rules

Activity/homework/practice/solution lesson files should be skipped entirely.

Apply this rule when the whole lesson file or lesson heading is mainly:

- Activity
- Homework
- Assignment
- Exercise
- Task
- Challenge
- Quiz
- Practice
- Solution
- Solutions

For these lessons:

- Do not create a summary note.
- Do not explain the requirements.
- Do not summarize the task.
- Do not summarize the solution.
- Do not include solution walkthroughs.
- Do not include downloadable solution files.
- Mark the task as `skipped_activity`.

This rule applies only when the whole lesson/file is mainly an activity, homework, practice task, quiz, or solution.

This rule does not apply to normal teaching lessons that contain examples, demos, code blocks, practical flows, or small exercises inside the explanation.

---

## Handling Different Lesson Styles

If the lesson has its own section style, preserve the structure when it helps understanding.

You may simplify messy formatting, but do not change the meaning.

If the source has an explicit conceptual order, preserve that order when it helps understanding.

If the source is unstructured, group related ideas based only on the content.

If the source contains a repeated idea, include it once in the best section.

## Report File Rules

Create one report set per command scope.

Do not create per-batch reports.

For `scope="subfolders 21-30"`, use:

- `_reports/review-21-30.md`
- `_reports/fix-21-30.md`
- `_reports/review-21-30-final.md`

Batches are only for worker execution, not for report files.

## Final Quality Checklist

Before writing the final summary, verify:

- The summary is in Egyptian Arabic.
- Teachable export metadata such as `Course:`, `Section:`, `Lecture:`, `URL:`, and `Export Date:` was removed.
- Course asset/download sections such as `Materials / Downloads`, `Source Code`, `Download`, `Use these images`, and `Complete and Continue` were removed unless they contain meaningful lesson explanation.
- Download-only lessons or sections were omitted from the final summary.
- Activity/homework/practice/solution lesson files were skipped entirely and marked as `skipped_activity`.
- Examples inside normal teaching lessons were preserved.
- The summary covers 100% of the meaningful teaching information.
- Repeated source ideas were not repeated unnecessarily.
- No external information was added.
- No unsupported examples were created.
- Technical terms are preserved accurately.
- Source code, commands, API examples, image references, and practical flows from normal teaching lessons were preserved as source content.
- Formatting and syntax choices are left to `obsidian-markdown` when needed.
- The conclusion does not introduce new ideas.
- The output path matches the assigned task.
